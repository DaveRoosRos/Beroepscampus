var APP_DATA = {
  "scenes": [
    {
      "id": "0-entree-langeweg-mono-lr",
      "name": "Entree Langeweg mono LR",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 512,
      "initialViewParameters": {
        "yaw": 1.5249438188128401,
        "pitch": 0.08543604941402805,
        "fov": 1.5129300417067528
      },
      "linkHotspots": [
        {
          "yaw": 1.4961864347050975,
          "pitch": 0.0012528793457917686,
          "rotation": 0,
          "target": "1-aula-mono-lr"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-aula-mono-lr",
      "name": "aula mono LR",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 512,
      "initialViewParameters": {
        "yaw": 1.3043768814568075,
        "pitch": -0.0017799176961261765,
        "fov": 1.5129300417067528
      },
      "linkHotspots": [
        {
          "yaw": -1.457345252163277,
          "pitch": 0.22571898393183076,
          "rotation": 0,
          "target": "0-entree-langeweg-mono-lr"
        },
        {
          "yaw": 1.512098685749491,
          "pitch": 0.1164807231849565,
          "rotation": 0,
          "target": "2-aula-mono-lr2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-aula-mono-lr2",
      "name": "Aula mono LR2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        }
      ],
      "faceSize": 512,
      "initialViewParameters": {
        "yaw": 1.3490254814050875,
        "pitch": -0.5179560495725575,
        "fov": 1.5129300417067528
      },
      "linkHotspots": [
        {
          "yaw": -1.4387173107241953,
          "pitch": 0.031763112721840514,
          "rotation": 0,
          "target": "0-entree-langeweg-mono-lr"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Beroepscampus",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
